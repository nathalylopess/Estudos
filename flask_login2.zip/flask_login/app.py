from flask import Flask, render_template \
    , url_for, request, redirect

from flask_login import LoginManager \
    , login_required, login_user, logout_user, current_user

from models import User, obter_conexao

from werkzeug.security import generate_password_hash, check_password_hash

login_manager = LoginManager()
app = Flask(__name__)
app.config['SECRET_KEY'] = 'SUPERMEGADIFICIL'
login_manager.init_app(app)

# quando precisar saber qual o usuario conectado
# temos como consultar ele no banco

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        matricula = request.form['matricula']
        senha = request.form['pass']
        
        user = User.get_by_matricula(matricula)
        
        if user:

            aux = check_password_hash(user.senha,senha)

            if user and aux == True:
                
                login_user(user)

                return render_template('dash.html')

    return render_template('login.html')


@app.route('/register', methods=['POST', 'GET'])
def register():

    if request.method == 'POST':

        #Gerar hash de uma string:
        #generate_password_hash('string')

        #Comparar hash e string:
        #check_password_hash(hash, 'string')

        matricula = request.form['matricula']

        email = request.form['email']
        email = generate_password_hash(email)

        senha = request.form['pass']
        senha = generate_password_hash(senha)

        conexao = obter_conexao()
        INSERT = 'INSERT INTO usuarios(matricula,email,senha) VALUES (?,?,?)'
        conexao.execute(INSERT, (matricula,email,senha))
        conexao.commit()
        conexao.close()

        user = User.get_by_email(email)
        
        if user and user.senha == senha:
            
            login_user(user)

            return render_template('dash.html')

    return render_template('register.html')

@app.route('/dash', methods=['POST', 'GET'])
@login_required
def dash():

    if request.method == 'POST':

        #user = User.get_by_matricula(matricula)

        matricula = current_user.id
        exercicio = request.form['exercicio']
        descricao = request.form['descricao']

        conexao = obter_conexao()
        INSERT = 'INSERT INTO exercicios(matricula, exercicio, descricao) VALUES (?,?,?)'
        conexao.execute(INSERT, (matricula, exercicio, descricao))
        conexao.commit()
        conexao.close()


    return render_template('dash.html')

@app.route('/logout', methods=['POST'])
def logout():
    logout_user()
    return render_template('index.html')


@app.route('/listarexercicios', methods=['GET'])
def listar():

    conexao = obter_conexao()
    cursor = conexao.cursor()

    SELECT = 'SELECT matricula, exercicio, descricao FROM exercicios WHERE matricula = ?'
    cursor.execute(SELECT, (current_user.id,))
    exercicios = cursor.fetchall()  # Aqui retornará uma lista de tuplas

    conexao.close()

    return render_template('listar_exercicio.html', exercicios=exercicios)
"""
@app.route('/excluir/<int:matricula>', methods=['GET', 'POST'])
@login_required
def excluir_exercicio(matricula):
    # Conectando ao banco de dados
    conexao = obter_conexao()
    cursor = conexao.cursor()

    # Deletando o exercício com base na matricula
    DELETE = 'DELETE FROM exercicios WHERE matricula = ? AND matricula = ?'
    cursor.execute(DELETE, (matricula, current_user.id))  # Verifica se o exercício pertence ao usuário atual
    conexao.commit()
    conexao.close()

    # Redireciona de volta para a página que lista os exercícios
    return redirect(url_for('listar'))


@app.route('/excluir_usuario/<int:matricula>', methods=['GET', 'POST'])
@login_required
def excluir_usuario(matricula):
    # Conectando ao banco de dados
    conexao = obter_conexao()
    cursor = conexao.cursor()

    # Deletando o usuário com base na matrícula
    DELETE = 'DELETE FROM usuarios WHERE matricula = ?'
    cursor.execute(DELETE, (matricula,))
    conexao.commit()
    conexao.close()

    # Deslogar o usuário se ele mesmo foi excluído
    if current_user.matricula == matricula:
        logout_user()

    # Redirecionar para a página inicial ou de administração
    return redirect(url_for('index'))"""